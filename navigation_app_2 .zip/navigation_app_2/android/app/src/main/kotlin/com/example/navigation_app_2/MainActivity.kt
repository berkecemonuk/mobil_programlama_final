package com.example.navigation_app_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
