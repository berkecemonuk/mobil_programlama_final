import 'package:flutter/material.dart';
import '../widgets/DrawerItem.dart';
import '../widgets/ProfileArea.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Social Media App"),
      ),
      drawer: Drawer(
        child: Column(
          children: [
            ProfileArea(
              avatar: 'assets/images/the-weeknd.jpeg',
              name: 'Berke',
              onT: () {
                Navigator.pushNamed(context, "/profile");
              },
            ),
            Expanded(
              child: Column(
                children: [
                  Divider(
                    color: Colors.grey,
                  ),
                  DrawerItem(
                    title: "Home",
                    icon: Icon(Icons.home_outlined, size: 25),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                  DrawerItem(
                    title: "Explore",
                    icon: Icon(Icons.explore_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/explore");
                    },
                  ),
                  DrawerItem(
                    title: "Shop",
                    icon: Icon(Icons.shop_2_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/shop");
                    },
                  ),
                  Divider(
                    color: Colors.grey,
                  ),
                  DrawerItem(
                    title: "About us",
                    icon: Icon(Icons.info_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/aboutus");
                    },
                  ),
                  DrawerItem(
                    title: "Settings",
                    icon: Icon(Icons.settings_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/settings");
                    },
                  ),
                  Divider(
                    color: Colors.grey,
                  ),
                  DrawerItem(
                    icon: Icon(Icons.logout_outlined),
                    onTap: () {
                      Navigator.pushNamedAndRemoveUntil(context, "/welcome", (route) => false);
                    },
                    title: "Logout",
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Text(
              "Sharethon 0.7.7",
              style: TextStyle(
                color: Colors.grey,
                fontSize: 10,
              ),
            ),
            SizedBox(height: 5),
          ],
        ),
      ),
      body: ListView.builder(
        itemCount: 7, // 7 adet gönderi
        itemBuilder: (context, index) {
          return PostCard(
            username: 'berke_cem_onuk_$index',
            imagePath: 'assets/images/post_$index.jpeg',
            caption: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ac ex at velit eleifend tincidunt.',
            commentCount: index * 5,
            shareCount: index * 3,
          );
        },
      ),
    );
  }
}

class PostCard extends StatefulWidget {
  final String username;
  final String imagePath;
  final String caption;
  final int commentCount;
  final int shareCount;

  const PostCard({
    Key? key,
    required this.username,
    required this.imagePath,
    required this.caption,
    required this.commentCount,
    required this.shareCount,
  }) : super(key: key);

  @override
  _PostCardState createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  bool isLiked = false;
  bool isSaved = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            leading: CircleAvatar(
              backgroundImage: AssetImage('assets/images/post_5.jpeg'),
            ),
            title: Text(widget.username),
          ),
          Image.asset(
            widget.imagePath, // Gönderi resmi
            fit: BoxFit.cover,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    IconButton(
                      icon: Icon(isLiked ? Icons.favorite : Icons.favorite_outline),
                      onPressed: () {
                        setState(() {
                          isLiked = !isLiked;
                        });
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.mode_comment),
                      onPressed: () {
                        // Yorum işlevselliği buraya eklenebilir
                      },
                    ),
                    IconButton(
                      icon: Icon(isSaved ? Icons.bookmark : Icons.bookmark_outline),
                      onPressed: () {
                        setState(() {
                          isSaved = !isSaved;
                        });
                      },
                    ),
                  ],
                ),
                SizedBox(height: 8),
                Text(
                  widget.caption,
                  style: TextStyle(fontSize: 14),
                ),
                SizedBox(height: 8),
                Row(
                  children: [
                    Text('${widget.commentCount} comments'),
                    SizedBox(width: 16),
                    Text('${widget.shareCount} shares'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
